from collections import defaultdict
from kubernetes import client, config
from collections import defaultdict
from kubernetes import client, config
from tabulate import tabulate
from termcolor import colored

from . import common
from . import settings

def list_jobs_in_namespace(namespace, batch_name, limit_length=None):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  core_api_instance = client.CoreV1Api()

  jobs = api_instance.list_namespaced_job(namespace, label_selector=f"{settings.batch_label}={batch_name}")
  table_data = []
  for job in jobs.items:
    # Get pods associated with the job
    pods = core_api_instance.list_namespaced_pod(namespace, label_selector=f"job-name={job.metadata.name}")

    status_counts = defaultdict(int)
    for pod in pods.items:
      status = common.get_job_status(pod)
      status_counts[status] += 1
    creation_timestamp = job.metadata.creation_timestamp

    row = [
      colored(batch_name, "cyan"),
      colored(job.metadata.name.replace(f"{batch_name}-",""), "yellow"),
      colored(status_counts['Succeeded'], "green"),
      colored(status_counts['Failed'], "red"),
      colored(status_counts['Running'], "blue"),
      colored(status_counts['Submitted'], "magenta"),
      colored(status_counts['Pending'], "grey"),
      colored(creation_timestamp, "white"),
    ]
    table_data.append(row)

  sorted_table = sorted(table_data, key=lambda x: x[-1], reverse=True)
  filtered_table = sorted_table[0:limit_length] if limit_length and len(sorted_table)>limit_length else sorted_table
  print(tabulate(filtered_table, headers=["Batch Name", "Job Name", "Succeeded", "Failed", "Running", "Submitted", "Pending", "Creation Timestep"]))

