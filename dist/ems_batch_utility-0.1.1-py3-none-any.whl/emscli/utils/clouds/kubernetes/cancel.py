from kubernetes import client, config, watch
import sys

from . import common
from . import settings


def cancel_batch(namespace, batch_name):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()

  jobs = api_instance.list_namespaced_job(namespace, label_selector=f"{settings.batch_label}={batch_name}")
  for job in jobs.items:
    job_name = job.metadata.name
    cancel_pod(namespace, job_name)
  return


def cancel_pod(namespace, job_name):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  try:
    api_instance.delete_namespaced_job(name=job_name, namespace=namespace, propagation_policy="Foreground")
    print(f"Job '{job_name}' canceled.")
  except client.rest.ApiException as e:
    if e.status == 404:  # Ignore NotFound errors
      print(f"{job_name} not found")
    else:
      raise RuntimeError(f"Error canceling job: {e}")


def cancel_job(namespace, batch_name, job_name):
  batch_job_name = f"{batch_name}-{job_name}"
  cancel_pod(namespace, batch_job_name)