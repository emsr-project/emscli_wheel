from collections import defaultdict
import copy
from datetime import datetime, timedelta
from kubernetes import client, config
from collections import defaultdict
from kubernetes import client, config
import pytz
from tabulate import tabulate
from termcolor import colored

from . import common
from . import settings


def list_jobs_by_group_name(namespace, group_name):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  core_api_instance = client.CoreV1Api()
  jobs = api_instance.list_namespaced_job(namespace, label_selector=f"{settings.batch_label}={group_name}")
  status_counts = defaultdict(int)
  for job in jobs.items:
    pods = core_api_instance.list_namespaced_pod(namespace, label_selector=f"job-name={job.metadata.name}")
    for pod in pods.items:
      status = common.get_job_status(pod)
      status_counts[status] += 1
  return status_counts


def list_all_groups(namespace):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  jobs = api_instance.list_namespaced_job(namespace)
  groups = {}
  for job in jobs.items:
    group = job.metadata.labels.get(f"{settings.batch_label}") or "unknown"
    creation_timestamp = job.metadata.creation_timestamp
    if group not in groups or creation_timestamp > groups[group]:
      groups[group] = creation_timestamp
  sorted_groups = sorted(groups.items(), key=lambda x: x[1], reverse=True)
  return sorted_groups


def list_all_namespaces():
  common.load_kubeconfig()
  api_instance = client.CoreV1Api()
  namespaces = api_instance.list_namespace()
  return [ns.metadata.name for ns in namespaces.items]


def filter_table_data(table_data, limit_length=None, active_only=False, verbose=False):
  filtered_data = copy.deepcopy(table_data)
  if verbose:
    now = datetime.now(pytz.UTC)
    two_weeks_ago = now - timedelta(weeks=2)
    filtered_data = [td for td in filtered_data if td['timestamp']>two_weeks_ago]
  if active_only:
    filtered_data = [td for td in filtered_data if td['status_counts']['Running']+td['status_counts']['Submitted']+td['status_counts']['Pending']>0]
  if limit_length:
    filtered_data = filtered_data[0:limit_length] if len(filtered_data)>limit_length else filtered_data
  return filtered_data


def paint_color(table_data):
  colored_table_data = []
  for td in table_data:
    colored_table_data.append([
        colored(td["namespace"], "cyan"),
        colored(td["batch_name"], "yellow"),
        colored(td["status_counts"]['Succeeded'], "green"),
        colored(td["status_counts"]['Failed'], "red"),
        colored(td["status_counts"]['Running'], "blue"),
        colored(td["status_counts"]['Submitted'], "magenta"),
        colored(td["status_counts"]['Pending'], "grey"),
        colored(td["timestamp"], "white"),
    ])
  return colored_table_data


def display_overview(namespace, limit_length=None, active_only=False, verbose=False ):
  namespaces = list_all_namespaces() if namespace=="-A" else [namespace]
  table_data = []
  for single_namespace in namespaces: 
    groups = list_all_groups(single_namespace)
    for group, timestamp in groups:
      status_counts = list_jobs_by_group_name(single_namespace, group)
      table_data.append({
        "namespace": single_namespace,
        "batch_name": group,
        "status_counts": status_counts,
        "timestamp": timestamp 
      })
  table_data = filter_table_data(table_data, limit_length, active_only, verbose)
  table_data = paint_color(table_data)
  print("\n" + colored("Job Information by Batch Name:", attrs=["bold"]))
  print(tabulate(table_data, headers=["Namespace", "Batch Name","Succeeded", "Failed", "Running", "Submitted", "Pending", "Creation Timestamp"]))
  print()
  return 