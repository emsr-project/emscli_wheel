import os
import time
from kubernetes import client, config, watch
from tabulate import tabulate
from termcolor import colored

from . import common
from . import settings


def submit_job(batch_name, job_name, container_image, command, namespace, cpu_num, gpu_num, memory_size, env_vars, overwrite=True):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  
  batch_job_name = f"{batch_name}-{job_name}"
  common.create_namespace(namespace)
  existing_job = common.get_existing_job(batch_job_name, namespace_name=namespace)
  # Delete the existing job if it exists, stuck until all resources are released
  if (existing_job is not None) and overwrite:
    delete_options = client.V1DeleteOptions(propagation_policy="Foreground")
    try:
      api_instance.delete_namespaced_job(batch_job_name, namespace, body=delete_options)
    except client.rest.ApiException as e:
      if e.status != 404:  # Ignore NotFound errors
        raise RuntimeError(f"Error happens when deleting jobs: {e}")
    # print(f"waiting existing {batch_job_name} to be terminated")
    while existing_job:
      existing_job = common.get_existing_job(batch_job_name, namespace_name=namespace)

  # Configure the Job
  job = client.V1Job(
    api_version="batch/v1",
    kind="Job",
    metadata=client.V1ObjectMeta(
      name=batch_job_name,
      labels={"user": namespace, f"{settings.batch_label}": batch_name, f"{settings.job_label}":job_name}  # Add the user label
    ),
    spec=client.V1JobSpec(
      backoff_limit=settings.backoff_limit,
      active_deadline_seconds=settings.active_deadline_seconds,
      ttl_seconds_after_finished = settings.ttl_seconds_after_finished,
      template=client.V1PodTemplateSpec(
        metadata=client.V1ObjectMeta(labels={"user": namespace, f"{settings.batch_label}": batch_name, f"{settings.job_label}":job_name}),  # Add the user label to the Pod template
        spec=client.V1PodSpec(
          containers=[
            client.V1Container(
                name="my-container",
                image=container_image,
                command=command,
                env=[client.V1EnvVar(name=_k, value=str(_v)) for (_k,_v) in env_vars.items()],
                resources=client.V1ResourceRequirements(  # Add resource limits and requests
                    limits={
                        "cpu": cpu_num,
                        "memory": memory_size,
                        "nvidia.com/gpu": gpu_num
                    },
                    requests={
                        "cpu": cpu_num,
                        "memory": memory_size,
                    },
                ),
                volume_mounts=[  # Add the volume mount to the container
                    client.V1VolumeMount(
                        name="host-path",
                        mount_path=f"{settings.container_mount_path}"
                    ),
                    client.V1VolumeMount(
                        mount_path="/dev/shm",
                        name="shm-volume"
                    ),
                ],
                image_pull_policy="Always",
            )
        ],
        restart_policy=settings.restart_policy,
        volumes=[  # Define the hostPath volume
            client.V1Volume(
                name="host-path",
                host_path=client.V1HostPathVolumeSource(
                    path=f"{settings.host_mount_path}"
                )
            ),
            client.V1Volume(
                  name="shm-volume",
                  empty_dir=client.V1EmptyDirVolumeSource(
                      medium="Memory"
                  )
            ),
          ]
        ),
      ),
    ),
  )

  # Create the Job
  try:
    api_instance.create_namespaced_job(namespace, job)
    print(f"Successfully submitted jobs {batch_job_name}")
  except client.rest.ApiException as e:
    raise RuntimeError(f"Error creating jobs {batch_job_name}: {e}")
