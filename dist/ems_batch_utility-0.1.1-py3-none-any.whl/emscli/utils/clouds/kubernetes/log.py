from kubernetes import client, config, watch
import sys

from . import common
from . import settings


def get_job_pod_name(batch_name, job_name, namespace):
  common.load_kubeconfig()
  batch_job_name = f"{batch_name}-{job_name}"
  api_instance = client.CoreV1Api()
  try:
    pod_list = api_instance.list_namespaced_pod(namespace, label_selector=f"job-name={batch_job_name}")
  except client.rest.ApiException as e:
    if e.status == 404:
      print(f"No pods found for job '{batch_job_name}'")
      return None
    else:
        raise

  if not pod_list.items:
    print(f"No pods found for job '{batch_job_name}'")
    return None
  
  # find lates related pods 
  sorted_pod_list = sorted(pod_list.items, key=lambda pod: pod.metadata.creation_timestamp, reverse=True)
  return sorted_pod_list[0].metadata.name


def print_pod_logs(pod_name, namespace):
  common.load_kubeconfig()
  api_instance = client.CoreV1Api()
  try:
    logs = api_instance.read_namespaced_pod_log(name=pod_name, namespace=namespace)
    print(logs,end="")
  except client.rest.ApiException as e:
    raise RuntimeError(f"Error reading logs: {e}")
  except KeyboardInterrupt as e:
    pass  


def stream_pod_logs_until_done(pod_name, namespace):
  common.load_kubeconfig()
  api_instance = client.CoreV1Api()
  try:
    # Wait until the pod is terminated
    pod_watch = watch.Watch()
    pod_done = False
    print_idx = -1
    idx = -1
    while not pod_done:
      logs = api_instance.read_namespaced_pod_log(name=pod_name, namespace=namespace, follow=True, _preload_content=False)
      for (idx,l) in enumerate(logs.stream()):
        if idx > print_idx:
          print(l.decode("utf-8"),end="")
      print_idx = idx
      for event in pod_watch.stream(api_instance.list_namespaced_pod, namespace, field_selector=f"metadata.name={pod_name}", timeout_seconds=5):
        pod_status = event['object'].status.phase
        if pod_status == "Succeeded" or pod_status == "Failed":
          print(f"\nbatch job is terminated with status '{pod_status}'.")
          pod_done = True
          pod_watch.stop()
          break
  except client.rest.ApiException as e:
    raise RuntimeError(f"Error streaming logs: {e}")
  except KeyboardInterrupt as e:
    pass


def stream_job_logs_until_done(namespace, batch_name, job_name, snapshot=False):
  pod_name = get_job_pod_name(batch_name, job_name, namespace)
  if pod_name:
    if snapshot:
      print_pod_logs(pod_name, namespace)
    else:
      common.wait_pod_for_running(namespace, pod_name)
      stream_pod_logs_until_done(pod_name, namespace)
