from datetime import datetime, timedelta, timezone
from kubernetes import client, config, watch

from . import common
from . import settings

def delete_jobs_older_than_n_days(namespace, n):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()
  jobs = api_instance.list_namespaced_job(namespace)
  now = datetime.now(timezone.utc)
  n_days_ago = now - timedelta(days=n)

  for job in jobs.items:
    job_creation_time = job.metadata.creation_timestamp
    if job_creation_time <= n_days_ago:
      # Delete the associated Jobs
      print(f"Deleting job {job.metadata.name} created on {job_creation_time}...")
      api_instance.delete_namespaced_job(job.metadata.name, namespace)
      print(f"Job {job.metadata.name} deleted.")

      # Delete the associated Pods
      api_instance_v1 = client.CoreV1Api()
      pods = api_instance_v1.list_namespaced_pod(namespace, label_selector=f"job-name={job.metadata.name}")
      for pod in pods.items:
          api_instance_v1.delete_namespaced_pod(pod.metadata.name, namespace)