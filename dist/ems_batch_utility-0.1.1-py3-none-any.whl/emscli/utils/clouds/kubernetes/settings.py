default_kubeconfig_path = "/home/ubuntu/.mkube/mkube/config/config" 
image_pull_policy = "Always"
#restartPolicy: This configuration applies to the containers within a Pod.  Always, OnFailure, Never
restart_policy = "Never"
#This configuration applies to Kubernetes Jobs. It specifies the number of times a Job can be retried before it is considered failed.
backoff_limit = 5
# By default, the activeDeadlineSeconds field is not set in a Kubernetes Job, which means there is no limit on the duration the Job can run. The Job will continue running until it either completes successfully, fails 
active_deadline_seconds = 31536000  # 1 year
# The Job and its associated resources (pods) will be automatically deleted 1 hour after the Job has finished.
ttl_seconds_after_finished = 31536000 # 1 month

host_mount_path = "/home/ubuntu/mnt_magics"
container_mount_path = "/home/ubuntu/mnt_magics"

batch_label = "batch-name"
job_label = "job-id"