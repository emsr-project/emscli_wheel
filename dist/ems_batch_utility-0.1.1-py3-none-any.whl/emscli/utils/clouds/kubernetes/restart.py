from kubernetes import client, config, watch
import sys
import time

from . import common
from . import settings


def restart_batch(namespace, batch_name):
  common.load_kubeconfig()
  api_instance = client.BatchV1Api()

  jobs = api_instance.list_namespaced_job(namespace, label_selector=f"{settings.batch_label}={batch_name}")
  for job in jobs.items:
    job_name = job.metadata.name.replace(f"{batch_name}-","")
    restart_job(namespace, batch_name, job_name)


def restart_job(namespace, batch_name, job_name):
  common.load_kubeconfig()
  batch_job_name = f"{batch_name}-{job_name}"
  api_instance = client.BatchV1Api()

  # Get the existing job
  try:
    existing_job = api_instance.read_namespaced_job(name=batch_job_name, namespace=namespace)
  except client.rest.ApiException as e:
    if e.status == 404:  # Ignore NotFound errors
      print(f"{batch_job_name} not found")
      return
    else:
      raise RuntimeError(f"Error in getting job: {e}")

  # Delete the existing job
  try:
    api_instance.delete_namespaced_job(name=batch_job_name, namespace=namespace, propagation_policy="Foreground")
    common.wait_for_job_deletion(namespace,batch_job_name)
    print(f"Deleted existing job: {batch_job_name}")
  except client.rest.ApiException as e:
    raise RuntimeError(f"Error in deleting job: {e}")

  # Remove resource_version and self_link from metadata
  existing_job.metadata.resource_version = None
  existing_job.metadata.self_link = None
  existing_job.spec.template.metadata.labels.pop("controller-uid", None)
  existing_job.spec.selector = None

  # Create a new job with the same spec
  new_job = client.V1Job(
    metadata=existing_job.metadata,
    spec=existing_job.spec,
  )

  try:
    api_instance.create_namespaced_job(namespace=namespace, body=new_job)
    print(f"Created new job: {batch_job_name}")
  except client.rest.ApiException as e:
    raise RuntimeError(f"Error in creating job: {e}")