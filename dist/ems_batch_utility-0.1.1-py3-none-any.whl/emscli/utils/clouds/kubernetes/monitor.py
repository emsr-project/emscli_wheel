from datetime import datetime, timedelta, timezone
from kubernetes import client, config, watch

from . import common
from . import settings

def get_pod_metrics(namespace, pod_name):
  common.load_kubeconfig()
  api_instance = client.CustomObjectsApi()

  # Get pod metrics
  pod_metrics = api_instance.get_namespaced_custom_object(
    "metrics.k8s.io", "v1beta1", namespace, "pods", pod_name
  )

  # Extract CPU and memory usage
  cpu_usage = pod_metrics["containers"][0]["usage"]["cpu"]
  memory_usage = pod_metrics["containers"][0]["usage"]["memory"]

  return cpu_usage, memory_usage
