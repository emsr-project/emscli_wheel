import os
import time
from kubernetes import client, config, watch
from tabulate import tabulate
from termcolor import colored

from . import settings


def load_kubeconfig():
  # Check if KUBECONFIG environment variable exists
  kubeconfig_env = os.environ.get("KUBECONFIG")

  if kubeconfig_env:
    # If KUBECONFIG is set, load the configuration from the environment variable
    config.load_kube_config(config_file=kubeconfig_env)
  else:
    # If KUBECONFIG is not set, load the default configuration
    config.load_kube_config(config_file=settings.default_kubeconfig_path)
  return


def get_job_status(pod):
  if pod.status.phase == "Succeeded":
    return "Succeeded"
  elif pod.status.phase == "Failed":
    return "Failed"
  elif pod.status.phase == "Running":
    return "Running"
  elif pod.status.phase == "Pending":
    return "Pending"
  else:
    return "Submitted"


def get_pod_labels(namespace, pod_name):
  config.load_kube_config()
  api_instance = client.CoreV1Api()
  try:
      pod = api_instance.read_namespaced_pod(name=pod_name, namespace=namespace)
      return pod.metadata.labels
  except client.rest.ApiException as e:
      print(f"Error getting pod labels: {e}")
      return None


def create_namespace(namespace_name, exist_ok=True):
  load_kubeconfig()
  core_api_instance = client.CoreV1Api()
  # Check if the namespace exists
  try:
    core_api_instance.read_namespace(namespace_name)
  except client.rest.ApiException as e:
    if e.status == 404:
      # Create the namespace if it doesn't exist
      namespace = client.V1Namespace(
        api_version="v1",
        kind="Namespace",
        metadata=client.V1ObjectMeta(name=namespace_name),
      )
      core_api_instance.create_namespace(body=namespace)
    else:
      raise


def get_existing_job(batch_job_name, namespace_name):
  load_kubeconfig()
  api_instance = client.BatchV1Api()
  # Check if the job already exists
  try:
    existing_job = api_instance.read_namespaced_job(batch_job_name, namespace_name)
  except client.rest.ApiException as e:
    if e.status != 404:  # Ignore NotFound errors
      raise RuntimeError(f"Error in reading namespace{e}")
    existing_job = None
  return  existing_job


def check_existing_batch(namespace, batch_name):
  load_kubeconfig()
  api_instance = client.BatchV1Api()
  jobs = api_instance.list_namespaced_job(namespace, label_selector=f"{settings.batch_label}={batch_name}")
  return True if len(jobs.items)>0 else False


def wait_for_job_deletion(namespace, job_name):
  load_kubeconfig()
  api_instance = client.BatchV1Api()
  w = watch.Watch()

  # Wait for the job to be deleted
  job_deleted = False
  for event in w.stream(api_instance.list_namespaced_job, namespace=namespace, timeout_seconds=300):
    if event['object'].metadata.name == job_name and event['type'] == 'DELETED':
      job_deleted = True
      print(f"Job {job_name} deleted.")
      break

  # Stop the watch if the job is not deleted within the timeout period
  if not job_deleted:
    w.stop()
    print(f"Job {job_name} was not deleted within the timeout period.")
    return


def wait_for_pods_deletion(namespace, job_name):
  # may not work well
  load_kubeconfig()
  api_instance = client.CoreV1Api()
  w = watch.Watch()

  # Filter pods by the job's label selector
  label_selector = f"job-name={job_name}"
  pods_deleted = True

  for event in w.stream(api_instance.list_namespaced_pod, namespace=namespace, label_selector=label_selector, timeout_seconds=300):
    if event['type'] == 'DELETED':
      print(f"Pod {event['object'].metadata.name} deleted.")
    else:
      # If any pod is not deleted within the timeout period, stop the watch and return
      pods_deleted = False
      w.stop()
      print(f"Pod {event['object'].metadata.name} was not deleted within the timeout period.")
      break

  if pods_deleted:
    print("All pods deleted.")


def wait_pod_for_running(namespace, pod_name):
  load_kubeconfig()
  w = watch.Watch()
  core_api_instance = client.CoreV1Api()

  # Watch for pod events in the specified namespace
  for event in w.stream(core_api_instance.list_namespaced_pod, namespace=namespace, field_selector=f"metadata.name={pod_name}", timeout_seconds=60):
    pod = event['object']
    pod_status = pod.status.phase

    # Check if the pod is related to the job and is running
    if pod_status == "Running" or pod_status == "Succeeded" or pod_status == "Failed":
      w.stop()
  return