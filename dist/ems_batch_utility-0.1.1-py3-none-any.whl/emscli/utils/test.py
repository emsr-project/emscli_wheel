import time

for i in range(1000):
  print("="*200,i,"="*200)
  time.sleep(1)