import subprocess
import yaml
import os
import socket
import time

def load_config(file_path):
    with open(file_path) as f:
        loaded_config = yaml.safe_load(f)
    return loaded_config

def save_config(Content, FilePath):
    with open(FilePath, 'w') as file:
        documents = yaml.dump(Content, file)
    return 

def check_job_config(job_config):
    """
    add job_name to job_specs filed, 
    convert invalid symbol to '_'
    """
    job_id = 0
    for job_spec in job_config["job_specs"]:
        if 'name' not in job_spec.keys():
            job_config["job_specs"][job_id]['name'] = f"job.{job_id}"
        job_id += 1

    job_config['name'] = check_name(job_config['name'])
    
    return job_config

def check_name(name):
    result = name.replace("_",".")
    x = result.split('.')    # returns a list with '' instead of the repeating ';'
    x = [i for i in x if i]  # deletes the '' from the list
    result = '.'.join(x)
    return result

def shell_exec(CmdList, Wait=True, ErroroOut=None):
    process_list = []
    output_list = []
    for cmd in CmdList:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=ErroroOut, shell=True)
        process_list.append(process)

        if Wait:
            output = process.stdout.read()
            output_list.append(output.decode('utf-8'))
    if Wait:
        return output_list
    else:
        return process_list

def convert_config(KubeConfig, JobConfig, JobSpec):
    # execute_cmd = ['/bin/bash', '-c', f"cd {JobConfig['code_folder']} && {JobSpec['command']}"]
    conda_env = 'py39'
    if "conda_env" in JobConfig['shared'].keys():
        conda_env = JobConfig['shared']['conda_env']
    execute_cmd = ['/bin/bash', '-c', f"source /opt/conda/etc/profile.d/conda.sh && conda activate {conda_env} && cd {JobConfig['code_folder']} && {JobSpec['command']}"]
    limit_memory = f"{int(JobConfig['shared']['memory_in_gb'])*1024}Mi"
    request_memory = f"{int(JobConfig['shared']['memory_in_gb'])*1024}Mi"
    request_cpu = f"{int(JobConfig['shared']['vcpus'])*1000}m"
    limit_gpu = f"{int(JobConfig['shared']['gpus'])}"
    request_gpu = f"{int(JobConfig['shared']['gpus'])}"
    image_name = JobConfig['image_name']
    
    target_config = dict(KubeConfig)
    target_config['metadata']['name'] = f"{JobConfig['name']}-{JobSpec['name']}"
    target_config['spec']['template']['spec']['containers'][0]['command'] = execute_cmd
    target_config['spec']['template']['spec']['containers'][0]['resources']['limits']['memory'] = limit_memory
    target_config['spec']['template']['spec']['containers'][0]['resources']['requests']['memory'] = request_memory
    target_config['spec']['template']['spec']['containers'][0]['resources']['requests']['cpu'] = request_cpu
    target_config['spec']['template']['spec']['containers'][0]['resources']['limits']['nvidia.com/gpu'] = limit_gpu
    target_config['spec']['template']['spec']['containers'][0]['resources']['requests']['nvidia.com/gpu'] = request_gpu
    target_config['spec']['template']['spec']['containers'][0]['image'] = image_name
    return target_config

class MKube:
    def __init__(self, MkubeConfigFile="/home/ubuntu/.mkube/mkube/config/mkube_config.yaml"):
        self.mkube_config = load_config(MkubeConfigFile)
        self.kube_example_config = load_config(self.mkube_config['kube_example_file'])
        self.kube_files_folder = self.mkube_config['kube_temp_folder']
        self.kube_config_file = self.mkube_config['kube_config_file']
        self.default_job_image = self.mkube_config['gpu_image']
        self.default_job_image_cpu = self.mkube_config['cpu_image']
        return
    
    def describe_jobs(self, JobIds=None):
        if JobIds is None:
            describe_output = shell_exec([f"kubectl get jobs --kubeconfig={self.kube_config_file}"], Wait=True)[0]
            self.print_status(describe_output)
        else:
            print("xxx")
            pass
        return
    
    def print_status(self, DirectOutput):
        print_string = DirectOutput.replace("COMPLETIONS", "Status     ")
        new_string = ""
        for _l in print_string.split("\n"):
            new_l = _l
            for _s in _l.split()[0:-1]:
                new_s = _s+","
                new_l = new_l.replace(_s,new_s)
            new_string+=f"{new_l}\n"
        print(new_string)
        return
    
    def submit_job_config(self, JobConfig, JobNames=None):
        # TODO: pod name, cluster name can not incluster "_", replace "_" by "-"
        # magics cluster kubeconfig: always append
        # copy folder
        # submit jobs
        kube_job_config = self.kube_example_config  
        job_config = JobConfig
        job_config = check_job_config(job_config)
        if 'image_name' in job_config.keys():
            job_config['image_name']  = job_config['image_name']  
        else:
            job_config['image_name'] = self.default_job_image if job_config['shared']['gpus'] > 0 else  self.default_job_image_cpu
        if JobNames is None:
            JobNames = [_j['name'] for _j in job_config['job_specs']]
        
        for job_spec in job_config['job_specs']:
            if job_spec['name'] in JobNames:
                target_job_config = convert_config(kube_job_config, job_config, job_spec)
                temp_file_path = f"{self.kube_files_folder}/{job_config['name']}-{job_spec['name']}.yaml"
                save_config(target_job_config, temp_file_path)
                create_output = shell_exec([f'kubectl delete -f {temp_file_path} --kubeconfig={self.kube_config_file}', 
                                            f"kubectl create -f {temp_file_path} --kubeconfig={self.kube_config_file}"], Wait=True,
                                            ErroroOut=subprocess.PIPE)[1]
                print(create_output)

        return 
    
    def submit_job_file(self, JobConfigFile, JobNames=None):
        job_config = load_config(JobConfigFile)
        job_config = check_job_config(job_config)
        self.submit_job_config(job_config, JobNames)
        return 
    
    def log_job(self, JobName):
        log_output = shell_exec([f'kubectl logs jobs/{JobName} --kubeconfig={self.kube_config_file}'], Wait=True)[0]
        print(log_output)
        return 
    
    def watch_jobq_name(self, JobqName):
        job_names = shell_exec(["kubectl get jobs %s | awk '{print $1}' "%(f"--kubeconfig={self.kube_config_file}")], Wait=True)[0].split("\n")[1:-1]
        for job_name in job_names:
            if JobqName in job_name:
                # self.wait_until_done(job_name)
                # status_output = shell_exec([f'kubectl get jobs/{job_name} '], Wait=True)[0]
                # print(status_output, end="")
                # log_output = shell_exec([f'kubectl logs jobs/{job_name} '], Wait=True)[0]
                # print(log_output)
                self.log_until_done(job_name)
                status_output = shell_exec([f'kubectl get jobs/{job_name}  --kubeconfig={self.kube_config_file}'], Wait=True)[0]
                print(status_output)
        return
    
    def wait_until_done(self, JobName):
        while True:
            job_status = shell_exec(["kubectl get jobs/"+JobName+f" --kubeconfig={self.kube_config_file} "+" | awk '{print $2}' "], 
                                    Wait=True)[0].split("\n")[1]
            if job_status=='' or job_status =='1/1':
                break
        
        return

    def log_until_done(self, JobName):
        previous_output = shell_exec([f'kubectl logs jobs/{JobName} --kubeconfig={self.kube_config_file}'], Wait=True, ErroroOut=subprocess.PIPE)[0]
        print(previous_output, end="")
        while True:
            job_status = shell_exec(["kubectl get jobs/"+JobName+f" --kubeconfig={self.kube_config_file} "+" | awk '{print $2}' "], 
                                    Wait=True)[0].split("\n")[1]
            current_output = shell_exec([f'kubectl logs jobs/{JobName} --kubeconfig={self.kube_config_file}'], Wait=True,
                                        ErroroOut=subprocess.PIPE)[0]
            
            # continuously log 
            if previous_output == "":
                previous_output = None
            log_output = current_output.split(previous_output)
            previous_output = current_output
            if len(log_output)>0:
                print(log_output[-1], end="")
            
            # break if succeed or error
            if job_status=='' or job_status =='1/1':
                break
            time.sleep(1)
        print()
        return
    
    def delete_job_name(self, JobName):
        delete_output = shell_exec([f'kubectl delete jobs/{JobName} --kubeconfig={self.kube_config_file}'], Wait=True)[0]
        print(delete_output)
        return 

    def describe_jobq_name(self, JobQName, Options):
        jobq_name = check_name(JobQName)
        if Options[0] == "-r":
            describe_output = shell_exec([f"kubectl get jobs --kubeconfig={self.kube_config_file}"], Wait=True)[0]
            lines = describe_output.split("\n")
            print_output = f"{lines[0]}"
            if len(lines)>1:
                for _l in lines[1:]:
                    if jobq_name in _l:
                        print_output+=f"\n{_l}"
            self.print_status(print_output)
        else:
            for job_spec_name in Options:
                job_spec_name = check_name(job_spec_name)
                job_name = f"{jobq_name}-{job_spec_name}"
                self.watch_jobq_name(job_name)    
