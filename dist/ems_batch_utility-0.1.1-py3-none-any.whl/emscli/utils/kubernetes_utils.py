import os
import time
from kubernetes import client, config, watch
from tabulate import tabulate
from termcolor import colored


def main():
    # Load Kubernetes configuration
    # config.load_kube_config()

    # Example usage:
    batch_name = "test.batch"
    job_name = "job14"
    container_image = "qinjielin/mbatch-container:v0.6"
    env_vars={}
    command = ["/bin/bash", "-c", "source /opt/conda/etc/profile.d/conda.sh && conda activate py39 && cd /home/ubuntu/mnt_magics/code_ws/qinjie/ai_ems/cli_ws/emscli/utils \
        && echo Starting at $(date) && df -h && python test.py"]
    user = "qinjie"

    from clouds.kubernetes import submit, overview, status, log, cancel, restart, clean, monitor
    # for i in range(1):
    #     job_name = f"job{i+15}"
    #     submit.submit_job(batch_name, job_name, container_image, command, namespace=user, cpu_num="1", gpu_num="0", memory_size="2Gi", env_vars=env_vars, overwrite=True)
    overview.display_overview("qinjie", limit_length=10, active_only=False, verbose=True)
    # status.list_jobs_in_namespace("qinjie", "run.sbatch")
    # status.list_jobs_in_namespace("qinjie", "test.batch")
    # log.stream_job_logs_until_done(user, batch_name, "job12")
    # cancel.cancel_job(user, batch_name, "job20")
    # submit.submit_job(batch_name, "job4", container_image, command, namespace=user, cpu_num="1", gpu_num="0", memory_size="2Gi", overwrite=True)
    # cancel.cancel_batch(user, "zzz.batch")
    # restart.restart_job(user, batch_name, "job21")
    # restart.restart_batch(user, batch_name)
    # log.stream_job_logs_until_done("qinjie", "qinjie.batch", "job0")
    # clean.delete_jobs_older_than_n_days(user, 1)

if __name__ == "__main__":
    main()
