import time

for i in range(100):
  print("="*20,i,"="*20)
  time.sleep(0.1)