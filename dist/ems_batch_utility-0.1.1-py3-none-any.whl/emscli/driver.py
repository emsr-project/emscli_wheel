import signal
import sys
import typing as tp

import emscli.commands
import emscli.commands.batch as batch
import emscli.error_codes

ENABLED_COMMANDS: tp.List[tp.Type[emscli.commands.CommandBase]] = [
  batch.BatchCommand
]

class CliDriver(emscli.commands.CommandBase):
  """Base entry point to access all ems cli commands."""
  NAME: tp.ClassVar[str] = "ems"
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = []
  SUB_COMMANDS: tp.ClassVar[tp.List[tp.Type[emscli.commands.CommandBase]]] = ENABLED_COMMANDS
  DESCRIPTION: tp.ClassVar[str] = "Cli entry point of ems tools."

  def execute(self) -> int:
    args = sys.argv[1:]
    try:
      self(args)
    except KeyboardInterrupt:
      sys.stdout.write("\n")
      return 128+signal.SIGINT
    except Exception as e:
      sys.stderr.write(f"{str(e)}\n")
      return emscli.error_codes.INTERNAL_ERROR
    
  
