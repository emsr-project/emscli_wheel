import abc
import argparse
import typing as tp

import emscli.commands.argument as argument
import emscli.error_codes


class CommandBase(abc.ABC):
  NAME: tp.ClassVar[str] = "command"
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = []
  SUB_COMMANDS: tp.ClassVar[tp.List["CommandBase"]] = []
  DESCRIPTION: tp.ClassVar[str] = ""
  EPILOG: tp.ClassVar[str] = "Copyright (c) NU-Magics"

  def __init__(self, parent_command: tp.Optional["CommandBase"] = None) -> None:
    self.parent_command = parent_command
    self.argument_list = self._build_argument_list()
    self.command_table = self._build_command_table()
    self.parser = self._build_parser()

  def __call__(self, args: tp.List[str]) -> int:
    if len(self.command_table) > 0:
      if len(args) == 0 or not (child_cmd := self.command_table.get(args[0])):
        self.parser.print_help()
        return emscli.error_codes.INVALID_PARAMETER
      return child_cmd(args[1:])
    try:
      parsed = self.parser.parse_args(args)
    except argparse.ArgumentError:
      self.parser.print_help()
      return emscli.error_codes.INVALID_PARAMETER
    return self.main(vars(parsed))

  def _build_argument_list(self) -> tp.List[argument.Argument]:
    return [argument.Argument.from_json(arg) for arg in self.ARGUMENTS]

  def _build_command_table(self) -> tp.Dict[str, "CommandBase"]:
    return {cls.NAME: cls(parent_command=self) for cls in self.SUB_COMMANDS}

  def _build_parser(self) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
      prog=self._get_command_path(),
      description=self.DESCRIPTION,
      epilog=self.EPILOG
    )
    if len(self.command_table.keys()):
      parser.add_argument(
        "command", 
        choices=self.command_table.keys(),
        help="The subcommand to execute",
        type=str,
      )
    for arg in self.argument_list:
      arg.register_to_parser(parser)
    return parser

  def _get_command_path(self) -> str:
    commands, parent = [self.NAME], self.parent_command
    while parent:
      commands.append(parent.NAME)
      parent = parent.parent_command
    commands.reverse()
    return " ".join(commands)

  def main(self, args: tp.Dict[str,tp.Any]) -> int:
    raise NotImplementedError()