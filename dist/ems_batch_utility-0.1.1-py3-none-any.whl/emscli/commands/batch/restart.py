import sys
import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.commands.batch.utils as batch_utils
import emscli.error_codes
import emscli.utils.clouds.kubernetes as ems_kubernetes


class RestartCommand(emscli.commands.CommandBase):
  NAME: tp.ClassVar[str] = "restart"
  DESCRIPTION: tp.ClassVar[str] = ("Restarts the specified batch or jobs. All existing output "
    "and logs are deleted, and the specified batch or jobs will be re-submitted with exactly the "
    "same configs as original.")
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    batch_common.argument.BATCH_ARG,
    {
      "name": "jobs",
      "help_text": "Optional job names. If no job name is supplied, the whole batch is restarted.",
      "extra": {
        "type": str,
        "nargs": "*",
      },
    },
  ]

  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    print(f"{args}")
    batch_name = args.get("batch")
    jobs_name = args.get("jobs")
    user_name = args.get("user") or batch_utils.get_current_username()
    if len(jobs_name) > 0:
      for job_name in jobs_name:
        ems_kubernetes.restart.restart_job(namespace=user_name, batch_name=batch_name, job_name=job_name)
    else:
      ems_kubernetes.restart.restart_batch(namespace=user_name, batch_name=batch_name)
    return 0