import typing as tp

import emscli.commands
import emscli.commands.batch.cancel as cancel
import emscli.commands.batch.clean as clean
import emscli.commands.batch.monitor as monitor
import emscli.commands.batch.overview as overview
import emscli.commands.batch.restart as restart
import emscli.commands.batch.status as status
import emscli.commands.batch.submit as submit

class BatchCommand(emscli.commands.CommandBase):
  """ Command interface for batch"""
  NAME: tp.ClassVar[str] = "batch"
  SUB_COMMANDS: tp.ClassVar[tp.List[tp.Type[emscli.commands.CommandBase]]] = [
    cancel.CancelCommand,
    clean.CleanCommand,
    monitor.MonitorCommand,
    overview.OverviewCommand,
    restart.RestartCommand,
    status.StatusCommand,
    submit.SubmitCommand,
  ]
  DESCRIPTION: tp.ClassVar[str] = "Batch related operations."