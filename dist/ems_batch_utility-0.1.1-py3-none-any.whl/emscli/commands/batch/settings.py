CODE_EFS_PATH = "/home/ubuntu/mnt_magics/code_ws"
DATA_EFS_PATH = "/home/ubuntu/mnt_magics/data_ws"
CODE_UNZIP_PATH = "/tmp/code"
DEFAULT_TAR_NAME = "code.tar.gz"

cpu_types = ["amd64"]
gpu_types = ["A100", "1080Ti", "2080Ti"]
container_images = {
  "cpu": "qinjielin/mbatch-container:v0.6",
  "gpu": "qinjielin/mbatch-container:v0.5",
}
max_memory_in_gb = 200
max_vcpus = 64
max_gpus = 4

default_conda_env = "py39"
default_container_image = container_images['cpu']
default_gpu_type = "A100"
default_gpus = 1
default_cpu_type = "amd64"
default_vcpus = 2
default_max_retry = 5
default_memory_in_gb = 4
default_shmsize = '256G'
default_timeout_in_hours = 720

