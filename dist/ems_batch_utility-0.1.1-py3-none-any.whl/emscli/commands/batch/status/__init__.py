import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.commands.batch.utils as batch_utils
import emscli.error_codes
import emscli.utils.clouds.kubernetes as ems_kubernetes


class StatusCommand(emscli.commands.CommandBase):
  NAME: tp.ClassVar[str] = "status"
  DESCRIPTION: tp.ClassVar[str] = "Show the running status of a specified batch."
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    batch_common.argument.BATCH_ARG,
    batch_common.argument.USER_ARG,
    batch_common.argument.RAW_ARG,
    batch_common.argument.LIMIT_ARG,
    {
      "name": "job",
      "help_text": (
        "Optional job name. If no job name is supplied, status of the whole batch is displayed."
      ),
      "extra": {"type": str, "nargs": "?",},
    },
    {
      "short_flag": "-s",
      "long_flag": "--snapshot",
      "help_text": "Show a snapshot of current status instead.",
      "extra": {"default": False, "action": "store_true",},
    },
  ]

  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    batch_name = args.get("batch")
    user_name = args.get("user") or batch_utils.get_current_username()
    job_name = args.get("job")
    if not job_name:
      ems_kubernetes.status.list_jobs_in_namespace(namespace=user_name, batch_name=batch_name, limit_length=args.get("limit")) # add limt
    else:
      ems_kubernetes.log.stream_job_logs_until_done(namespace=user_name, batch_name=batch_name, job_name=job_name, snapshot=args.get("snapshot"))
    return 0