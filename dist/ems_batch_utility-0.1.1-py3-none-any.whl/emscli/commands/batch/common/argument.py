import typing as tp

MAX_PAGE: tp.Final[int] = 1000

BATCH_ARG: tp.Final[tp.Dict[str, tp.Any]] = {
  "name": "batch",
  "help_text": "Batch name.",
  "extra": {"type": str},
}
USER_ARG: tp.Final[tp.Dict[str, tp.Any]] = {
  "short_flag": "-u",
  "long_flag": "--user",
  "help_text": "Shows batches under a different user.",
  "extra": {"type": str},
}
RAW_ARG: tp.Final[tp.Dict[str, tp.Any]] = {
  "short_flag": "-r",
  "long_flag": "--raw-output",
  "help_text": "Shows results in raw csv format instead.",
  "extra": {"default": False, "action": "store_true"},
}
LIMIT_ARG: tp.Final[tp.Dict[str, tp.Any]] = {
  "short_flag": "-l",
  "long_flag": "--limit",
  "help_text": "Maximum number of entries that can be returned.",
  "extra": {"type": int, "default": MAX_PAGE},
}