import os
import shutil
import sys
import typing as tp

import emscli.commands
import emscli.commands.batch.utils as batch_utils
import emscli.error_codes
import emscli.utils.clouds.kubernetes as ems_kubernetes
from . import config as config_module
from . import files
from . import parser


class SubmitCommand(emscli.commands.CommandBase):
  NAME: tp.ClassVar[str] = "submit"
  DESCRIPTION: tp.ClassVar[str] = """
  Description: 
  1. Copy the code directory to a shared volume accessible by the Kubernetes cluster.
  2. Create a Kubernetes Job manifest using the provided input parameters.
  3. Submit the Kubernetes Job to the cluster using the Python kubernetes library.
  """
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    {
      "name": "config",
      "help_text": "Path to json file containing the computing configuration.",
      "extra": {"type": str, "nargs": "?"},
    },
    {
      "short_flag": "-y",
      "long_flag": "--yes-overwrite",
      "help_text": "Automatically overwrite if a batch with the same name exists.",
      "extra": {"default": False, "action": "store_true"},
    },
  ]

  def main(self, args: tp.List[tp.Dict[str, tp.Any]]) -> int:
    # ensure config can be matched
    try:
      config = config_module.read_and_validate_config(args["config"])
      jobs = parser.parse_job_specs(config)
      for job in jobs:
        job.valida_job_parameters()
    except RuntimeError as e:
      print(e)
      return emscli.error_codes.INVALID_PARAMETER
    batch_name = config["name"]
    user = batch_utils.get_current_username()
    # ensure batch can be created
    try:
      delete_existing_batch(user=user, batch=batch_name, overwrite=args.get("yes_overwrite"))
      files.generate_target_folder(batch=batch_name)
    except RuntimeError as e:
      print(e)
      return emscli.error_codes.RESOURCE_CONFLICT
    # copying code
    try:
      files.copy_code(source=config["code_folder"], target=batch_utils.get_batch_code_folder(batch_name), 
                ignore=config.get("ignore_globs"))
    except RuntimeError as e:
      print(e, "Clearning up...")
      files.delete_batch_folder(batch=batch_name)
      return emscli.error_codes.INVALID_PARAMETER
    # submit jobs to kubernetes
    for job in jobs:
      # break
      ems_kubernetes.settings.backoff_limit = job.max_retry
      ems_kubernetes.settings.active_deadline_seconds = job.timeout_in_hours * 60 * 60
      ems_kubernetes.submit.submit_job(batch_name=job.batch_name, job_name=job.job_name, 
        container_image=job.container_image, 
        command=job.get_bash_command(), 
        namespace=user, 
        cpu_num=f"{job.vcpus}", gpu_num=f"{job.gpus}", memory_size=f"{job.memory_in_gb}Gi", 
        env_vars=job.get_env_vars(), 
        overwrite=True)
    return 0


def delete_existing_batch(user:str, batch: str, overwrite: bool) -> None:
  # cancel existing
  if ems_kubernetes.common.check_existing_batch(batch_name=batch, namespace=user):
    print(f"Batch {batch} already exists in Kubernete Cluster.")
    if not overwrite:
      conf = ""
      while conf not in ["y", "n"]:
        conf = input("Overwrite and continue [y/n]?").lower()
      if conf == "y":
        overwrite = True
    if overwrite:
      ems_kubernetes.cancel.cancel_batch(batch_name=batch, namespace=user)
    else:
      raise RuntimeError("Batch name conflicts with an existing batch.")
  # clean batch code folder 
  files.delete_batch_folder(batch)
  return
