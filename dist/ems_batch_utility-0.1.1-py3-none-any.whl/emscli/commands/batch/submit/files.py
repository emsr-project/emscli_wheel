import fnmatch
import math
import os
import progressbar
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import typing as tp
import uuid

import emscli.commands.batch.utils as batch_utils
import emscli.commands.batch.settings as batch_settings

PROGRESS_UPDATE_INTERVAL: tp.Final[float] = 0.5


def delete_batch_folder(batch: str) -> None:
  target_folder = batch_utils.get_batch_folder(batch)
  if os.path.isdir(target_folder):
    shutil.rmtree(target_folder)


def generate_target_folder(batch: str) -> str:
  print("Creating batch resource folders...")
  target_folder = batch_utils.get_batch_folder(batch)
  os.makedirs(target_folder)
  return target_folder


# dangerous
def copy_code(source: str, target: str, ignore: tp.Optional[tp.List[str]] = None) -> None:
  print(f"Create a tar for code folder...")
  tarball = _zip_program(os.path.expanduser(source), ignore or ["*.ipynb", "*.pyc"])
  os.makedirs(target, exist_ok=True)
  total = os.path.getsize(tarball)
  copy_finished = False

  def _update_progress():
    pbar = progressbar.ProgressBar(widgets=[
      f"Total: {to_prefixed_storage_rep(total)}  ", progressbar.Percentage(), " ", progressbar.Bar(), " ",
      progressbar.AdaptiveETA(), " ", progressbar.FileTransferSpeed(),
    ], maxval=total).start()
    while True:
      time.sleep(PROGRESS_UPDATE_INTERVAL)
      copied = min(get_folder_size(target), total)
      pbar.update(copied)
      if copied >= total or copy_finished:
        pbar.update(total)
        pbar.finish()
        return

  prog_th = threading.Thread(target=_update_progress)
  try:
    sys.stdout.write("Copying the target program...\n")
    prog_th.start()
    shutil.copy(tarball, f"{target}/{batch_settings.DEFAULT_TAR_NAME}")
    os.remove(tarball)
  except (OSError, shutil.Error) as e:
    raise RuntimeError from e
  finally:
    copy_finished = True
    prog_th.join()


def _zip_program(source: str, ignore: tp.List[str]) -> str:
  """Creates a tar containing all files from the source folder, excluding IGNORE files"""
  with tempfile.TemporaryDirectory() as tmpdir:
    # tmp_code_folder needed since copytree enforces the target directory does not exist
    tmp_code_folder = f"{tmpdir}/code"
    tar_path = f"/tmp/{batch_utils.get_current_username()}_{uuid.uuid4()}.tar.gz"
    try:
      shutil.copytree(source, tmp_code_folder, ignore=shutil.ignore_patterns(*ignore))
      subprocess.run(f"cd {tmp_code_folder} && tar -zcf {tar_path} .", shell=True, check=True)
    except (OSError, shutil.Error) as e:
      raise RuntimeError(str(e)) from e
    return tar_path


def get_folder_size(folder: str, ignore_globs: tp.Optional[tp.List[str]] = None) -> int:
  """Computes the total size of files in the given folder, excluding any file
  or folders matching the ignore_globs."""
  total = 0
  ignore_globs = ignore_globs or []
  for dirpath, dirs, filenames in os.walk(folder, topdown=True):
    # Modifying dirs in-place causes os.walk to ignore the removed dirs
    dirs[:] = [d for d in dirs if not any(fnmatch.fnmatch(d, g) for g in ignore_globs)]
    for f in filenames:
      fp = os.path.join(dirpath, f)
      if not os.path.islink(fp) and not any(fnmatch.fnmatch(fp, g) for g in ignore_globs):
        total += os.path.getsize(fp)
  return total


def to_prefixed_storage_rep(num_bytes: int) -> str:
  """calculate the size in best unit."""
  prefixes = " KMGTPEZY"
  power = int(math.log(max(num_bytes, 1), 1000))
  scaled = num_bytes / 1000 ** power
  return f"{scaled:6.2f}{prefixes[power]}B"
