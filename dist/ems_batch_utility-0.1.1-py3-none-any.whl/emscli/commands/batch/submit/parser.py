import copy
import dataclasses
import json
import sys
import typing as tp
import jsonschema

import emscli.commands.batch.utils as batch_utils
import emscli.commands.batch.settings as batch_settings


@dataclasses.dataclass
class Job:
  """Class representing a batch job."""
  batch_name: str
  code_path: str
  index: int
  job_name: str

  command: str = "echo Hello world!"
  conda_env: str = dataclasses.field(default=f"{batch_settings.default_conda_env}")
  container_image: str = batch_settings.default_container_image
  cpu_family: str = batch_settings.default_cpu_type
  env_vars: tp.Dict[str, str] = dataclasses.field(default_factory=dict)
  gpu_type: str = batch_settings.default_gpu_type
  gpus: int = batch_settings.default_gpus
  max_retry: int = batch_settings.default_max_retry
  memory_in_gb: float = batch_settings.default_memory_in_gb
  notes: str = ""
  shm_size: str = batch_settings.default_shmsize
  timeout_in_hours: float = batch_settings.default_timeout_in_hours
  vcpus: int = batch_settings.default_vcpus

  def to_dict(self) -> tp.Dict:
    return dataclasses.asdict(self)
  
  def valida_job_parameters(self):
    if "'" in self.command:
     raise RuntimeError(f"job_{self.index}: Disallowed character ' is found in the supplied command.")
  
  def get_bash_command(self) -> tp.List[str]:
    old_bash = ["/bin/bash", "-c", f"source /opt/conda/etc/profile.d/conda.sh && conda activate {self.conda_env}\
  && echo Starting at $(date) && echo {self.notes} && cd {self.code_path} && {self.command}"]
    time_command = f"echo Starting at $(date)"
    conda_command = f"source /opt/conda/etc/profile.d/conda.sh && conda activate {self.conda_env}"
    mkdir_command = f"mkdir -p $CODE_PATH"
    copy_command = f"cp {self.code_path}/{batch_settings.DEFAULT_TAR_NAME} $CODE_PATH/."
    untar_command = f"tar -xzf $CODE_PATH/{batch_settings.DEFAULT_TAR_NAME} -C $CODE_PATH"
    job_command = f"cd $CODE_PATH && {self.command}"
    bash_command = ["/bin/bash", "-c", f"{time_command} && {conda_command} && {mkdir_command} && {copy_command} && {untar_command} && {job_command}"]
    return bash_command

  def get_env_vars(self) -> tp.Dict[str,str]:
    envs = {
      "CODE_PATH": batch_settings.CODE_UNZIP_PATH,
    }
    envs.update(self.env_vars)
    return envs

  @classmethod
  def from_dict(cls, data: tp.Dict):
    return cls(**data)


def parse_job_specs(config: dict) -> tp.List[Job]:
  """Parses the config file and returns a list of jobs constructed."""
  name = config["name"]
  code_folder = batch_utils.get_batch_code_folder(name)
  common = config["shared"]
  job_specs = config["job_specs"]
  def build_job(index: int) -> Job:
    dict_rep: dict = copy.deepcopy(common)
    for k, v in tp.cast(dict, job_specs[index]).items():
      if k == "env_vars":
        env_vars = dict_rep.get(k, {})
        env_vars.update(v)
        dict_rep[k] = env_vars
      else:
        dict_rep[k] = v
    dict_rep["batch_name"] = name
    dict_rep["index"] = index
    dict_rep["job_name"] = f"job{index}"
    dict_rep["code_path"] = code_folder
    if "container_image" not in common.keys():
      dict_rep["container_image"] = batch_settings.container_images['cpu'] if ("gpus" not in common.keys()) or (common["gpus"]==0) else batch_settings.container_images['gpu']
    return Job.from_dict(dict_rep)
  return [build_job(i) for i in range(len(job_specs))]