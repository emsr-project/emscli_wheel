import copy

import emscli.commands.batch.settings as batch_settings

nonempty_string = {"type": "string", "minLength": 1,}
nonnegative_integer = {"type": "integer", "minimum": 0,}
positive_integer = {"type": "integer", "minimum": 1,}

ulimit_dict = {
  "type": "object",
  "properties": {
    "soft": positive_integer,
    "hard": positive_integer,
  },
  "additionalProperties": False,
}

sharable_job_spec = {
  "additionalProperties": False,
  "type": "object",
  "properties": {
    "conda_env": nonempty_string,
    "container_image": {
      "type": "string",
      "enum": list(batch_settings.container_images.values()),
    },
    "cpu_family": {
      "type": "string",
      "enum": batch_settings.cpu_types,
    },
    "env_vars": {
      "type": "object",
      "propertyNames": {"pattern": "^[a-zA-Z][a-zA-Z0-9_]*$"},
    },
    "gpu_type": {
      "type": "string",
      "enum": batch_settings.gpu_types,
    },
    "gpus": {
      "type": "integer",
      "minimum": 0,
      "maximum": batch_settings.max_gpus,
    },
    "job_type": {
      "type": "string",
      "enum": ["general_purpose", "cpu_intensive", "memory_intensive"],
    },
    "max_retry": nonnegative_integer,
    "memory_in_gb": {
      "type": "integer",
      "minimum": 1,
      "maximum": batch_settings.max_memory_in_gb,
    },
    "shm_size": nonempty_string,
    "timeout_in_hours": {"type": "integer", "minimum": 1, "maximum": 14 * 24},
    "vcpus": {
      "type": "integer",
      "minimum": 1,
      "maximum": batch_settings.max_vcpus,
    },
  },
}

job_schema: dict = copy.deepcopy(sharable_job_spec)
job_schema["properties"]["command"] = nonempty_string
job_schema["properties"]["notes"] = {"type": "string"}

config_schema = {
  "type": "object",
  "properties": {
    "before_all": nonempty_string,
    "code_folder": nonempty_string,
    "ignore_globs": {"type": "array", "items": nonempty_string},
    "job_specs": {"type": "array", "items": job_schema},
    "name": {
      "type": "string",
      "minLength": 1,
      "maxLength": 1024,
      "pattern": r"^[a-zA-Z_][a-zA-Z0-9_\-\.]*$",
    },
    "shared": sharable_job_spec,
  },
  "required": ["code_folder", "job_specs", "name",],
}