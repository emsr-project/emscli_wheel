import copy
import json
import sys
import typing as tp
import jsonschema

from . import schema


def read_and_validate_config(path: tp.Optional[str]) -> tp.Dict[str, tp.Any]:
  """Loads batch config and validates the configs input."""
  try:
    config = _read_config(path)
  except jsonschema.ValidationError as e:
    sys.stderr.write("The supplied config failed to pass schema valiation:\n")
    sys.stderr.write(f"{str(e)}\n")
    raise RuntimeError from e
  except (OSError, ValueError, RuntimeError) as e:
    sys.stderr.write(f"{str(e)}\n")
    raise RuntimeError from e
  return config


def _read_config(path: tp.Optional[str]) -> tp.Dict[str, tp.Any]:
  """Loads batch config from the given path and validates the input config. If the
  path is None, read from piped stdin instead."""
  if path is not None:
    with open(path, encoding="utf-8") as f:
      config = json.load(f)
  elif not sys.stdin.isatty():
    config = json.load(sys.stdin)
  else:
    raise RuntimeError("No usable input stream for config loading.")
  jsonschema.validate(instance=config, schema=schema.config_schema)
  return config