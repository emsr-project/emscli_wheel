import sys
import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.commands.batch.utils as batch_utils
import emscli.error_codes
import emscli.utils.clouds.kubernetes as ems_kubernetes


class CancelCommand(emscli.commands.CommandBase):
  NAME: tp.ClassVar[str] = "cancel"
  DESCRIPTION: tp.ClassVar[str] = "Cancel a previously submitted batch or job."
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    batch_common.argument.BATCH_ARG,
    {
      "name": "jobs",
      "help_text": "List of job names you only want to cancel.",
      "extra": {"type": str, "nargs": "*"},
    },
    batch_common.argument.USER_ARG,
  ]

  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    batch_name = args.get("batch")
    jobs_name = args.get("jobs")
    user_name = args.get("user") or batch_utils.get_current_username()
    if len(jobs_name) > 0:
      for job_name in jobs_name:
        ems_kubernetes.cancel.cancel_job(namespace=user_name, batch_name=batch_name, job_name=job_name)
    else:
      ems_kubernetes.cancel.cancel_batch(namespace=user_name, batch_name=batch_name)
    return 0