import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.commands.batch.utils as batch_utils
import emscli.error_codes
import emscli.utils.clouds.kubernetes as ems_kubernetes


class DaysAgoCommand(emscli.commands.CommandBase):
  """Clean up previous batches submitted a certain number of days ago."""
  NAME: tp.ClassVar[str] = "days-ago"
  DESCRIPTION: tp.ClassVar[str] = (
    "Delete all batches submitted N days ago, where N is specified by the user."
  )
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    {
      "name": "days",
      "help_text": (
        "The number of days. All batches submitted this many days ago will be deleted."
      ),
      "extra": {"type": int},
    }
  ]

  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    user_name = args.get("user") or batch_utils.get_current_username()
    num_days = args.get("days")
    ems_kubernetes.clean.delete_jobs_older_than_n_days(namespace=user_name, n=num_days)
    return 0


class CleanCommand(emscli.commands.CommandBase):
  """Entry point for all batch cleaning related commands."""
  NAME: tp.ClassVar[str] = "clean"
  DESCRIPTION: tp.ClassVar[str] = "Delete previously submitted batches."
  SUB_COMMANDS: tp.ClassVar[tp.List[tp.Type[emscli.commands.CommandBase]]] = [
    DaysAgoCommand,
  ]
