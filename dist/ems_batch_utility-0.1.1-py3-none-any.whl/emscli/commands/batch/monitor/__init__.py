import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.error_codes

class MonitorCommand(emscli.commands.CommandBase):
  """This class contains all APIs to query the status of a batch and its jobs."""
  NAME: tp.ClassVar[str] = "monitor"
  DESCRIPTION: tp.ClassVar[str] = "Monitor the resource usage of a job."
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    batch_common.argument.BATCH_ARG,
    batch_common.argument.USER_ARG,
    {
      "name": "job",
      "help_text": "job_name",
      "extra": {"type": str,},
    },
  ]

  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    print(f"executing ems batch monitor {args}")
    return 0