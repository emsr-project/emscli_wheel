import os
import pwd
import typing as tp

from . import settings


def get_batch_folder(name: str, user: tp.Optional[str]=None) -> str:
  user = user or get_current_username()
  return f"{settings.CODE_EFS_PATH}/{user}/batch/{name}"


def get_batch_code_folder(name: str, user: tp.Optional[str]=None) -> str:
  """"return folder, used for containing code zip file"""
  return f"{get_batch_folder(name, user)}/code"


def get_batch_data_folder(name: str, user: tp.Optional[str]=None) -> str:
  """"currently not used"""
  user = user or get_current_username()
  return f"{settings.DATA_EFS_PATH}/{user}"


def get_current_username() -> str:
  """Gets current username."""
  return pwd.getpwuid(os.getuid()).pw_name