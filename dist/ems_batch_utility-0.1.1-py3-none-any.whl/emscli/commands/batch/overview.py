import sys
import typing as tp

import emscli.commands
import emscli.commands.batch.common as batch_common
import emscli.commands.batch.utils as batch_utils
import emscli.utils.clouds.kubernetes as ems_kubernetes


class OverviewCommand(emscli.commands.CommandBase):
  NAME: tp.ClassVar[str] = "overview"
  DESCRIPTION: tp.ClassVar[str] = "Show the running status of all batches."
  ARGUMENTS: tp.ClassVar[tp.List[tp.Dict[str, tp.Any]]] = [
    {
      "short_flag": "-a",
      "long_flag": "--all-users",
      "help_text": "Whether to show status across all users.",
      "extra": {"default": False, "action": "store_true"},
    },
    {
      "short_flag": "-k",
      "long_flag": "--active-only",
      "help_text": "Whether to show unfinished batches only.",
      "extra": {"default": False, "action": "store_true"},
    },
    {
      "short_flag": "-v",
      "long_flag": "--verbose",
      "help_text": "Whether to show all batches (instead of only those submitted within two weeks).",
      "extra": {"default": False, "action": "store_true"},
    },
    batch_common.argument.USER_ARG,
    batch_common.argument.LIMIT_ARG,
  ]
  def main(self, args: tp.Dict[str, tp.Any]) -> int:
    if args.get("all_users"):
      ems_kubernetes.overview.display_overview(namespace="-A", limit_length=args.get("limit"), active_only=args.get("active_only"), verbose=args.get("verbose"))
    else:
      user_name = args.get("user") if args.get("user") else batch_utils.get_current_username()
      ems_kubernetes.overview.display_overview(namespace=user_name, limit_length=args.get("limit"), active_only=args.get("active_only"), verbose=args.get("verbose"))
    return 0