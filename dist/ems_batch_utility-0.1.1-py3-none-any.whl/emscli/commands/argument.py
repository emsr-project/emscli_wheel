import abc
import argparse
import typing as tp


class Argument(abc.ABC):
  "Base class for all command"
  @abc.abstractmethod
  def register_to_parser(self, parser: argparse.ArgumentParser) -> None:
    """register an argument to argparser"""

  @classmethod
  def from_json(cls, json: tp.Dict[str, tp.Any]) -> "Argument":
    if "name" in json:
      return PostionalArgument(json["name"], json["help_text"], **json["extra"])
    return OptionalArgument(
      json["help_text"],
      short_flag=json["short_flag"],
      long_flag=json["long_flag"],
      **json["extra"],
    )


class PostionalArgument(Argument):
  """class to represent positional argument for all commands"""
  def __init__(self, name: str, help_text: str, **kwargs: tp.Any) -> None:
    if not is_valid_positional_arg_name(name):
      raise ValueError(f"Invalid positional argument name: {name}")
    self.name = name
    self.help_text = help_text
    self.kwargs = kwargs

  def register_to_parser(self, parser: argparse.ArgumentParser) -> None:
    parser.add_argument(self.name, help=self.help_text, **self.kwargs)


class OptionalArgument(Argument):
  """Class to represent optional argument like -v for jcap cli commands."""
  def __init__(self, help_text: str, short_flag: str, long_flag: str, **kwargs: tp.Any) -> None:
    if not is_valid_short_flag(short_flag):
      raise ValueError(f"Invalid short flag: {short_flag}")
    if not is_valid_long_flag(long_flag):
      raise ValueError(f"Invalid long flag: {long_flag}")
    self.help_text = help_text
    self.short_flag = short_flag
    self.long_flag = long_flag
    self.kwargs = kwargs

  def register_to_parser(self, parser: argparse.ArgumentParser) -> None:
    parser.add_argument(self.short_flag, self.long_flag, help=self.help_text, **self.kwargs)


def is_valid_short_flag(flag: str) -> bool:
  """Tests if a string is valid short flag name."""
  return flag.startswith("-") and not flag.startswith("--")


def is_valid_long_flag(flag: str) -> bool:
  """Tests if a string is valid long flag name."""
  return flag.startswith("--") and not flag.startswith("---")


def is_valid_positional_arg_name(name: str) -> bool:
  """Tests if a string is valid positional argument name."""
  return not name.startswith("-")