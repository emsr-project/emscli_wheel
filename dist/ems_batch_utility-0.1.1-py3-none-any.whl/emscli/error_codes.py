"""This module includes all ems cli error codes."""
import typing as tp

RESOURCE_CONFLICT: tp.Final[int] = 10
INVALID_PARAMETER: tp.Final[int] = 11
INTERNAL_ERROR: tp.Final[int] = 12
SERVICE_UNAVAILABLE: tp.Final[int] = 13